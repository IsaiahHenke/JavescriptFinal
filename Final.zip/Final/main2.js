//fetching the API
fetch("https://pokeapi.co/api/v2/pokemon?limit=151")
  .then(response => response.json())
  .then(data => {
    //making each button
    const pokemonList = document.getElementById("pokemon-list");
    data.results.forEach(pokemon => {
      const button = document.createElement("button");
      //button text formatting
      pokemonName = pokemon.name;
      pokemonName = pokemonName.substring(0, 1).toUpperCase() + pokemonName.substring(1);
      button.textContent = pokemonName;
      button.addEventListener("click", () => {
        fetch(pokemon.url)
          .then(response => response.json())
          .then(pokemonCard => {
            console.log(pokemonCard);
            
            //card data
            const name = document.createElement("p");
            const sprite = document.createElement("img");
            const type = document.createElement("p");
            const pId = document.createElement("p");

            //name functions
            pokemonName = pokemon.name;
            pokemonName = pokemonName.substring(0, 1).toUpperCase() + pokemonName.substring(1);
            name.textContent = pokemonName;
            console.log(pokemonName);

            //sprite functions
            sprite.src = pokemonCard.sprites.front_default;
            sprite.alt = pokemonCard.name;

            //type functions
            pokemonCard.types.forEach(pokemonTypes => {
              const typeText = document.createTextNode(pokemonTypes.type.name);
              type.appendChild(typeText);
              type.appendChild(document.createElement("br"));
              console.log(typeText);
            });

            //pId functions
            pokemonId = pokemonCard.id;
            pId.textContent = pokemonId;
            console.log(pokemonId);

            //card box
            const cardBox = document.createElement("div")
            cardBox.style.width = "200px";
            cardBox.style.height = "300px";
            cardBox.style.backgroundColor = "lightGrey";
            cardBox.style.border = "5px solid yellow";

            //append data to card box
            cardBox.appendChild(name);
            cardBox.appendChild(sprite);
            cardBox.appendChild(type);
            cardBox.appendChild(pId);
            document.body.appendChild(cardBox);
          })
          .catch(error => console.error(error));
      });
      pokemonList.appendChild(button);
    });
  })
  .catch(error => console.error(error));